#!/usr/bin/env python
"""
AIMO Reference Problem Evaluation Script
Evaluates solver against 5 IMO/AIME level problems from reference.csv
"""
import os
import sys
import json
import time
from pathlib import Path
from typing import Dict, Any

# Add project root to path
BASE_DIR = Path(__file__).parent.absolute()
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / "src"))

from pipeline.orchestrator import PipelineOrchestrator

# AIMO problem data (from reference.csv)
AIMO_PROBLEMS = [
    {
        "id": "0e644e",
        "problem": "Let $ABC$ be an acute-angled triangle with integer side lengths and $AB<AC$. Points $D$ and $E$ lie on segments $BC$ and $AC$, respectively, such that $AD=AE=AB$. Line $DE$ intersects $AB$ at $X$. Circles $BXD$ and $CED$ intersect for the second time at $Y \\neq D$. Suppose that $Y$ lies on line $AD$. There is a unique such triangle with minimal perimeter. This triangle has side lengths $a=BC$, $b=CA$, and $c=AB$. Find the remainder when $abc$ is divided by $10^{5}$.",
        "answer": "336",
        "difficulty": "IMO"
    },
    {
        "id": "26de63",
        "problem": "Define a function $f \\colon \\mathbb{Z}_{\\geq 1} \\to \\mathbb{Z}_{\\geq 1}$ by\n\\begin{equation*}\n    f(n) = \\sum_{i = 1}^n \\sum_{j = 1}^n j^{1024} \\left\\lfloor\\frac1j + \\frac{n-i}{n}\\right\\rfloor.\n\\end{equation*}\nLet $M=2 \\cdot 3 \\cdot 5 \\cdot 7 \\cdot 11 \\cdot 13$ and let $N = f{\\left(M^{15}\\right)} - f{\\left(M^{15}-1\\right)}$. Let $k$ be the largest non-negative integer such that $2^k$ divides $N$. What is the remainder when $2^k$ is divided by $5^7$?",
        "answer": "32951",
        "difficulty": "IMO"
    },
    {
        "id": "424e18",
        "problem": "A tournament is held with $2^{20}$ runners each of which has a different running speed. In each race, two runners compete against each other with the faster runner always winning the race. The competition consists of $20$ rounds with each runner starting with a score of $0$. In each round, the runners are paired in such a way that in each pair, both runners have the same score at the beginning of the round. The winner of each race in the $i^{\\text{th}}$ round receives $2^{20-i}$ points and the loser gets no points.\n\nAt the end of the tournament, we rank the competitors according to their scores. Let $N$ denote the number of possible orderings of the competitors at the end of the tournament. Let $k$ be the largest positive integer such that $10^k$ divides $N$. What is the remainder when $k$ is divided by $10^{5}$?",
        "answer": "21818",
        "difficulty": "IMO"
    },
    {
        "id": "42d360",
        "problem": "On a blackboard, Ken starts off by writing a positive integer $n$ and then applies the following move until he first reaches $1$. Given that the number on the board is $m$, he chooses a base $b$, where $2 \\leq b \\leq m$, and considers the unique base-$b$ representation of $m$,\n\\begin{equation*}\n    m = \\sum_{k = 0}^\\infty a_k \\cdot b^k\n\\end{equation*}\nwhere $a_k$ are non-negative integers and $0 \\leq a_k < b$ for each $k$. Ken then erases $m$ on the blackboard and replaces it with $\\sum\\limits_{k = 0}^\\infty a_k$.\n\nAcross all choices of $1 \\leq n \\leq 10^{10^5}$, the largest possible number of moves Ken could make is $M$. What is the remainder when $M$ is divided by $10^{5}$?",
        "answer": "32193",
        "difficulty": "IMO"
    },
    {
        "id": "641659",
        "problem": "Let $ABC$ be a triangle with $AB \\neq AC$, circumcircle $\\Omega$, and incircle $\\omega$. Let the contact points of $\\omega$ with $BC$, $CA$, and $AB$ be $D$, $E$, and $F$, respectively. Let the circumcircle of $AFE$ meet $\\Omega$ at $K$ and let the reflection of $K$ in $EF$ be $K'$. Let $N$ denote the foot of the perpendicular from $D$ to $EF$. The circle tangent to line $BN$ and passing through $B$ and $K$ intersects $BC$ again at $T \\neq B$.\n\nLet sequence $(F_n)_{n \\geq 0}$ be defined by $F_0 = 0$, $F_1 = 1$ and for $n \\geq 2$, $F_n = F_{n-1} + F_{n-2}$. Call $ABC$ $n$\\emph{-tastic} if $BD = F_n$, $CD = F_{n+1}$, and $KNK'B$ is cyclic. Across all $n$-tastic triangles, let $a_n$ denote the maximum possible value of $\\frac{CT \\cdot NB}{BT \\cdot NE}$. Let $\\alpha$ denote the smallest real number such that for all sufficiently large $n$, $a_{2n} < \\alpha$. Given that $\\alpha = p + \\sqrt{q}$ for rationals $p$ and $q$, what is the remainder when $\\left\\lfloor p^{q^p} \\right\\rfloor$ is divided by $99991$?",
        "answer": "57447",
        "difficulty": "IMO"
    }
]


def main():
    """Main evaluation loop for AIMO problems"""
    print("=" * 80)
    print("AIMO Reference Problem Evaluation")
    print("=" * 80)
    print(f"Problems: {len(AIMO_PROBLEMS)}")
    print(f"Difficulty: IMO/AIME Level")
    print(f"Answer Range: 0-99999 (5-digit integers)")
    print()
    
    # Check FAST_TEST mode
    fast_test = os.getenv("AIMO_FAST_TEST", "0") == "1"
    if fast_test:
        print("⚠️  FAST_TEST mode enabled - using stub LLM (answers will be incorrect)")
        print()
    
    # Initialize orchestrator
    orchestrator = PipelineOrchestrator()
    
    # Results tracking
    results = []
    correct = 0
    total = len(AIMO_PROBLEMS)
    
    # Solve each problem
    for idx, problem_data in enumerate(AIMO_PROBLEMS, 1):
        print(f"\n{'=' * 80}")
        print(f"Problem {idx}/{total}: {problem_data['id']} ({problem_data['difficulty']})")
        print(f"{'=' * 80}")
        print(f"Problem: {problem_data['problem'][:200]}...")
        print()
        
        start_time = time.time()
        
        try:
            # Solve problem using orchestrator
            result = orchestrator.solve_problem(
                domain="math_olympiad",
                variables={},
                problem_text=problem_data["problem"],
                time_budget=300.0  # 5 minutes per problem
            )
            elapsed = time.time() - start_time
            
            # Extract answer
            predicted_answer = result.get("answer", "ERROR")
            expected_answer = problem_data["answer"]
            is_correct = str(predicted_answer) == str(expected_answer)
            
            if is_correct:
                correct += 1
            
            # Store result
            result_entry = {
                "id": problem_data["id"],
                "difficulty": problem_data["difficulty"],
                "expected": expected_answer,
                "predicted": predicted_answer,
                "correct": is_correct,
                "method": result.get("method", "UNKNOWN"),
                "verification_status": result.get("verification_status", "UNKNOWN"),
                "elapsed_time": elapsed
            }
            results.append(result_entry)
            
            # Print result
            status = "[OK] CORRECT" if is_correct else "[FAIL] WRONG"
            print(f"\n{status}")
            print(f"Expected: {expected_answer}")
            print(f"Predicted: {predicted_answer}")
            print(f"Method: {result.get('method', 'N/A')}")
            print(f"Verification: {result.get('verification_status', 'N/A')}")
            print(f"Time: {elapsed:.2f}s")
            
        except Exception as e:
            print(f"[ERROR]: {str(e)}")
            elapsed = time.time() - start_time
            results.append({
                "id": problem_data["id"],
                "difficulty": problem_data["difficulty"],
                "expected": problem_data["answer"],
                "predicted": "ERROR",
                "correct": False,
                "method": "ERROR",
                "verification_status": "ERROR",
                "elapsed_time": elapsed,
                "error": str(e)
            })
    
    # Final summary
    print(f"\n{'=' * 80}")
    print("FINAL RESULTS")
    print(f"{'=' * 80}")
    print(f"Correct: {correct}/{total} ({100*correct/total:.1f}%)")
    print()
    
    # Save results
    results_dir = BASE_DIR / "results"
    results_dir.mkdir(exist_ok=True)
    results_file = results_dir / "aimo_evaluation_results.json"
    
    with open(results_file, "w") as f:
        json.dump({
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_problems": total,
            "correct": correct,
            "accuracy": correct / total,
            "fast_test_mode": fast_test,
            "results": results
        }, f, indent=2)
    
    print(f"Results saved to: {results_file}")
    print()
    
    # Detailed breakdown
    print("Problem-by-Problem:")
    for r in results:
        status = "[OK]" if r["correct"] else "[FAIL]"
        print(f"  {status} {r['id']}: {r['predicted']} (expected: {r['expected']}) - {r['elapsed_time']:.1f}s")


if __name__ == "__main__":
    main()
